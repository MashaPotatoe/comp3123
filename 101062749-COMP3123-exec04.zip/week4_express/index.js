const express = require('express');
const app = express();
const SERVER_PORT = 3000

app.get('/', (req, res) => {
    res.send('<h1>Hello World</h1>');
});

app.get('/about', (req, res) => {
    res.send('<h1>About</h1>');
});

app.get('/contact', (req, res) => {
    res.send('<h1>Contact</h1>');
});

app.get('/hello', (req, res) => {
    res.status(200)
    res.send('<h1>GET - HELLO EXPRESS JS</h1>');
});


// can only get method in browser so we have to use postman, fetch method, or postman 
app.post('/hello', (req, res) => {
    res.status(201)
    res.send('<h1>POST - Hello World Another</h1>');

});

app.get('/student', (req, res) => {
    res.status(200)
    const stud = {
        name: 'John Doe',
        age: 25
    }
    res.json(stud) 
});


//query parameter
http://localhost:3000/studentu?fnm=Mash&lnm=Nova

app.get('/studentu', (req,res) => {
    console.log(req.query); 
    const fnm = req.query.fnm;
    const lnm = req.query.lnm;
    res.send(`First name: ${fnm}, Last name: ${lnm}`);
});


//http://localhost:3000/student/name/name/etc

app.get('/studentu/:fnm/:lnm/:city', (req,res) => {
    console.log(req.params)
    const fnm = req.params.fnm;
    const lnm = req.params.lnm;
    const city = req.params.city;
    res.send(`First name: ${fnm}, Last name: ${lnm}, City: ${city}`);
});





app.put('/hello', (req, res) => {
    res.status(203)
    res.send('<h1>PUT - Hello World Another</h1>');
});

app.delete('/hello', (req, res) => {
    res.status(204)
    res.send('<h1>DELETE - Hello World Another</h1>');
});

app.listen(SERVER_PORT, () => {
    console.log(`Server is running on http://localhost:${SERVER_PORT}`);
});
